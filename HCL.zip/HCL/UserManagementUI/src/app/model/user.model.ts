export class User {
    UserName?: string;  
    PassCode?: string;  
    FirstName?: string;  
    LastName?: string;  
    EmailId? : string;
    IsActive?: boolean;
} 