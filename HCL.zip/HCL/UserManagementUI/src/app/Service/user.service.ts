import { Injectable } from '@angular/core';  
import { HttpClient } from '@angular/common/http';  
import { User } from '../model/user.model';  
import { map } from 'rxjs/operators';  

@Injectable({  
  providedIn: 'root'  
})  
export class UserService {  
  
  constructor(private http: HttpClient) { }  
  baseUrl: string = 'http://localhost:44370/user/';  
  
  getUsers() {  
    return this.http.get<User[]>(this.baseUrl);  
  }  
  deleteUser(userName: string) {  
    return this.http.delete<number>(this.baseUrl + userName);  
  }  
  createUser(user: User) {  
    return this.http.post(this.baseUrl, user);  
  }  
 
  updateUser(user: User) {  
    return this.http.put(this.baseUrl + '/' + user.UserName, user);  
  }
  getUserByUserName(user: string) {  
    return this.http.get<User>(this.baseUrl + '/' + user);  
  }

  login(url:any, payload:any) {
    return this.http.post(`${this.baseUrl}${url}`, payload).pipe(map(res => {
    return res;
    }));
    }
}  