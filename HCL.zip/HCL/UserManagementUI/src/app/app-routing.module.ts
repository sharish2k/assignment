import { NgModule } from '@angular/core';  
import { CommonModule } from '@angular/common';  
import { RouterModule, Routes } from '@angular/router';  
import { ListUserComponent } from './list-user/list-user.component';  
import { AddUserComponent } from './add-user/add-user.component'; 
import { LoginComponent } from './login/login.component';  
  

export const routes: Routes = [  
    { path: '', component: LoginComponent, pathMatch: 'full' },  
    { path: 'list-user', component: ListUserComponent },  
    { path: 'add-user', component: AddUserComponent }  
  ];
  
@NgModule({  
  imports: [  
    CommonModule,  
    RouterModule.forRoot(routes)  
  ],  
  exports: [RouterModule],  
  declarations: []  
})  
export class AppRoutingModule { } 