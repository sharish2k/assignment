import { Component, OnInit } from '@angular/core';  
import { FormBuilder, FormGroup, Validators } from "@angular/forms";  
import { UserService } from '../Service/user.service';  
import { Router } from "@angular/router";  
  
@Component({  
  selector: 'app-add-user',  
  templateUrl: './add-user.component.html',  
  styleUrls: ['./add-user.component.css']  
})  
export class AddUserComponent implements OnInit {  
  
  userformlabel: string = 'Add User';  
  userformbtn: string = 'Save';  
  constructor(private formBuilder: FormBuilder, private router: Router, private userService: UserService) {  
  }  
  
  addForm: any;  
  btnvisibility: boolean = true;  
  ngOnInit() {  
  
    this.addForm = this.formBuilder.group({  
      id: [],  
      employee_name: ['', Validators.required],  
      employee_salary: ['', [Validators.required, Validators.maxLength(9)]],  
      employee_age: ['', [Validators.required, Validators.maxLength(3)]]  
    });  
  
    let username = localStorage.getItem('editUserName');  
    if (username != null) {  
      this.userService.getUserByUserName(username).subscribe(data => {  
        this.addForm.patchValue(data);  
      })  
      this.btnvisibility = false;  
      this.userformlabel = 'Edit User';  
      this.userformbtn = 'Update';  
    }  
  }  
  onSubmit() {  
    this.userService.createUser(this.addForm.value)  
      .subscribe(data => {  
        this.router.navigate(['list-user']);  
      },  
      error => {  
        alert(error);  
      });  
  }  
  onUpdate() {  
    this.userService.updateUser(this.addForm.value).subscribe(data => {  
      this.router.navigate(['list-user']);  
    },  
      error => {  
        alert(error);  
      });  
  }  
}  