import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import { UserService } from '../Service/user.service';
import { Router } from '@angular/router';
@Component({
selector: 'app-login',
templateUrl: './login.component.html',
styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
isLogin: boolean = false

constructor( private _api: UserService, private _router:Router)
 { }
ngOnInit() {

}
onSubmit(form: NgForm) {

this._api.login('login', form.value).subscribe((res: any) => {
if (res.status) {
    this._router.navigate(['list-user']);
} else {
}
});
}

}