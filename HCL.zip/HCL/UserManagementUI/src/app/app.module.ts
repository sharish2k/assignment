import { BrowserModule } from '@angular/platform-browser';  
import { NgModule } from '@angular/core';  
import { HttpClientModule } from '@angular/common/http';  
import { AppRoutingModule } from './app-routing.module';  
import { ReactiveFormsModule } from "@angular/forms";  
  
import { AppComponent } from './app.component';  
import { ListUserComponent } from './list-user/list-user.component';  
import { AddUserComponent } from './add-user/add-user.component';  
import { UserService } from './Service/user.service';
import { LoginComponent } from './login/login.component'; 

@NgModule({  
  declarations: [  
    AppComponent,  
    ListUserComponent,  
    AddUserComponent, LoginComponent  
  ],  
  imports: [  
    BrowserModule,  
    HttpClientModule,  
    AppRoutingModule,  
    ReactiveFormsModule  
  ],  
  providers: [UserService],  
  bootstrap: [AppComponent]  
})  
export class AppModule { }  
