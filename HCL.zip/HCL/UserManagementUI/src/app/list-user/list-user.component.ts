import { Component, OnInit } from '@angular/core';  
import { UserService } from '../Service/user.service';  
import { User } from '../model/user.model';  
import { Router } from "@angular/router";  
import { Observable } from 'rxjs';
  
@Component({  
  selector: 'app-list-user',  
  templateUrl: './list-user.component.html',  
  styleUrls: ['./list-user.component.css']  
})  
export class ListUserComponent implements OnInit {  
  
  users: User[] = [];  
  
  constructor(private userService: UserService, private router: Router) { 

  }  
  
  ngOnInit() {  
    this.userService.getUsers()  
      .subscribe((data: User[]) => {  
        this.users = data;  
      });  
  }  
  deleteUser(user: User): void {  
    this.userService.deleteUser(user.UserName || '{}')  
      .subscribe(data => {  
        this.users = this.users.filter(u => u !== user);  
      })  
  }  
  editUser(user: User): void {  
    localStorage.removeItem('editUserName');  
    localStorage.setItem('editUserName', user.UserName || '{}');  
    this.router.navigate(['add-user']);  
  }  
}  