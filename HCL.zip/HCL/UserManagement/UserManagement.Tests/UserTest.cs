﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Rhino.Mocks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Results;
using UserManagement;
using UserManagement.Controllers;
using UserManagement.DataModel;

namespace UserManagement.Tests
{
    [TestClass]
    public class UserTest
    {
        [TestMethod]
        public void GetAllUsersTest()
        {
            var controller = new UserController();
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            var users = GetUsers();
            var dataFactory = MockRepository.GenerateMock<IDBConnection>();
            dataFactory.Expect(s => s.ReadUsers()).Return(GetUsers()).IgnoreArguments();

            // Act on Test  
            var response = controller.GetUsers() as OkNegotiatedContentResult<List<User>>;
            Assert.IsNotNull(response);
            var result = response.Content;
            Assert.AreEqual(users.Count, result.Count);
        }

        [TestMethod]
        public void GetUserByIdTest()
        {
            var controller = new UserController();
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            var users = GetUsers().FirstOrDefault(i => i.UserId == "TestUser1");
            var dataFactory = MockRepository.GenerateMock<IDBConnection>();
            dataFactory.Expect(s => s.GetUserByID("TestUser1")).Return(users).IgnoreArguments();

            // Act on Test  
            var response = controller.GetUsers() as OkNegotiatedContentResult<User>;
            Assert.IsNotNull(response);
            var result = response.Content;
            Assert.AreEqual(users.FirstName, result.FirstName);
        }

        [TestMethod]
        public void UpdateTest()
        {
            var controller = new UserController();
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            var users = GetUsers().FirstOrDefault(i => i.UserId == "TestUser1");
            users.FirstName = "HarishUpdate";
            var dataFactory = MockRepository.GenerateMock<IDBConnection>();
            dataFactory.Expect(s => s.UpdateUser(users)).Return(users).IgnoreArguments();

            // Act on Test  
            var response = controller.GetUsers() as OkNegotiatedContentResult<User>;
            Assert.IsNotNull(response);
            var result = response.Content;
            Assert.AreEqual(users.FirstName, result.FirstName);
        }

        [TestMethod]
        public void InsertTest()
        {
            var controller = new UserController();
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            var users = GetUsers().FirstOrDefault(i => i.UserId == "TestUser1");
            var dataFactory = MockRepository.GenerateMock<IDBConnection>();
            dataFactory.Expect(s => s.InsertUser(users)).Return(users).IgnoreArguments();

            // Act on Test  
            var response = controller.GetUsers() as OkNegotiatedContentResult<User>;
            Assert.IsNotNull(response);
            var result = response.Content;
            Assert.AreEqual(users.FirstName, result.FirstName);
        }


        [TestMethod]
        public void DeleteUserTest()
        {
            var controller = new UserController();
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            var users = GetUsers().FirstOrDefault(i => i.UserId == "TestUser1");
            var dataFactory = MockRepository.GenerateMock<IDBConnection>();
            dataFactory.Expect(s => s.DeleteUser(users.UserId)).Return(true).IgnoreArguments();

            // Act on Test  
            var response = controller.GetUsers() as OkNegotiatedContentResult<bool>;
            Assert.IsNotNull(response);
            var result = response.Content;
            Assert.IsTrue(result);
        }



        private List<User> GetUsers()
        {
            List<User> users = new List<User>();
            users.Add(new User() { UserId = "TestUser1", FirstName = "Harish", LastName = "Varma", EmailId = "harish@gmail.com", IsActive = true });
            users.Add(new User() { UserId = "TestUser2", FirstName = "Girish", LastName = "Rao", EmailId = "Girish@gmail.com", IsActive = true });
            users.Add(new User() { UserId = "TestUser3", FirstName = "Satish", LastName = "Kumar", EmailId = "Satish@gmail.com", IsActive = true });
            users.Add(new User() { UserId = "TestUser4", FirstName = "Suresh", LastName = "Reddy", EmailId = "Suresh@gmail.com", IsActive = true });

            return users;

        }
    }
}
