﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserManagement.DataModel
{
    public interface IDBConnection
    {

        User InsertUser(User user);

        List<User> ReadUsers();

        User UpdateUser(User user);

        bool DeleteUser(string userId);

        User GetUserByID(string userId);

    }
}
