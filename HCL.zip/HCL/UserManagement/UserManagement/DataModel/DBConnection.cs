﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserManagement.DataModel
{
    public class DBConnection : IDBConnection
    {
        SQLiteConnection conn;

        public DBConnection()
        {
            this.conn = this.CreateConnection();
        }
        public SQLiteConnection CreateConnection()
        {

            SQLiteConnection sqlite_conn;
            // Create a new database connection:
            sqlite_conn = new SQLiteConnection("Data Source= c://sqlite//Users.db; Version = 3; New = True; Compress = True; ");
            // Open the connection:
            try
            {
                sqlite_conn.Open();
            }
            catch (Exception ex)
            {

            }
            return sqlite_conn;
        }

        public User InsertUser(User user)
        {
            try
            {
                SQLiteCommand sqlite_cmd;
                sqlite_cmd = conn.CreateCommand();
                sqlite_cmd.CommandText = "INSERT INTO User VALUES(" + user.UserId + ",'" + user.FirstName + ",'" + user.LastName + ",'" + user.EmailId + ",'" + user.IsActive + ");";
                sqlite_cmd.ExecuteNonQuery();
                return user;
            }
            catch (Exception)
            {
                return null;
            }

        }

        public User Login(User user)
        {
            SQLiteDataAdapter ad;
            DataTable dt = new DataTable();
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();
            sqlite_cmd.CommandText = "SELECT * FROM User where userId = "+ user.UserId +"IsActive = 1";
            ad = new SQLiteDataAdapter(sqlite_cmd);
            ad.Fill(dt); //fill the datasource

            conn.Close();
            if (dt.Rows.Count > 0)
            {
                return user;
            }
            else
            {
                return null;
            }
        }

        public List<User> ReadUsers()
        {
            SQLiteDataAdapter ad;
            DataTable dt = new DataTable();
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();
            sqlite_cmd.CommandText = "SELECT * FROM User where IsActive = 1";
            ad = new SQLiteDataAdapter(sqlite_cmd);
            ad.Fill(dt); //fill the datasource

            List<User> users = dt.AsEnumerable().Select(dataRow => new User
                {
                    UserId = dataRow.Field<string>("UserId"),
                    FirstName = dataRow.Field<string>("FirstName"),
                    LastName = dataRow.Field<string>("LastName"),
                    EmailId = dataRow.Field<string>("Email"),
                    IsActive = dataRow.Field<bool>("IsActive"),
                }).ToList();

            conn.Close();

            return users;
        }

        public User UpdateUser(User user)
        {
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();
            sqlite_cmd.CommandText = "Update User set Firstname = '" + user.FirstName + "',LastName = '" + user.LastName + "', Email = '" + user.EmailId + "' where userId = " + user.UserId +"";

            sqlite_cmd.ExecuteNonQuery();
            
            conn.Close();

            return user;
        }

        public bool DeleteUser(string userId)
        {
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();
            sqlite_cmd.CommandText = "Update User set IsActive = 0 where userId = " + userId + "";

            sqlite_cmd.ExecuteNonQuery();

            conn.Close();
            return true;
        }

        public User GetUserByID(string userId)
        {
            SQLiteDataAdapter ad;
            DataTable dt = new DataTable();
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();
            sqlite_cmd.CommandText = "SELECT * FROM User where IsActive = 1";
            ad = new SQLiteDataAdapter(sqlite_cmd);
            ad.Fill(dt); //fill the datasource

            conn.Close();
            if (dt.Rows.Count > 0)
            {
                User user = new User()
                {
                    UserId = dt.Rows[0].Field<string>("UserId"),
                    FirstName = dt.Rows[0].Field<string>("FirstName"),
                    LastName = dt.Rows[0].Field<string>("LastName"),
                    EmailId = dt.Rows[0].Field<string>("Email"),
                    IsActive = dt.Rows[0].Field<bool>("IsActive"),
                };

                return user;
            }
            else
            {
                return null;
            }
        }
    }
}
