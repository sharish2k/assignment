﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UserManagement.DataModel;

namespace UserManagement.Controllers
{
    [RoutePrefix("Api/User")]
    public class UserController : ApiController
    {
        DBConnection objEntity = new DBConnection();

        [HttpGet]
        [Route("AllUsers")]
        public IQueryable<User> GetUsers()
        {
            try
            {
                return objEntity.ReadUsers().AsQueryable();
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpGet]
        [Route("GetUserById/{userId}")]
        public IHttpActionResult GetUserById(string userId)
        {
            User objUser = new User();
            try
            {
                objUser = objEntity.GetUserByID(userId);
                if (objUser == null)
                {
                    return NotFound();
                }

            }
            catch (Exception)
            {
                throw;
            }

            return Ok(objUser);
        }

        [HttpPost]
        [Route("InsertUser")]
        public IHttpActionResult InsertUser(User data)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                objEntity.InsertUser(data);
            }
            catch (Exception)
            {
                throw;
            }

            return Ok(data);
        }

        [HttpPost]
        [Route("Login")]
        public IHttpActionResult LoginUser(User data)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                objEntity.Login(data);
            }
            catch (Exception)
            {
                throw;
            }

            return Ok(data);
        }

        [HttpPut]
        [Route("UpdateUserDetails")]
        public IHttpActionResult PutUser(User user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                User objEmp = new User();
                objEmp = objEntity.GetUserByID(user.UserId);
                if (objEmp != null)
                {
                    objEmp.FirstName = user.FirstName;
                    objEmp.LastName = user.LastName;
                    objEmp.EmailId = user.EmailId;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Ok(user);
        }

        [HttpDelete]
        [Route("DeleteUser")]
        public IHttpActionResult DeleteUser(string id)
        {
            //int empId = Convert.ToInt32(id);  
            User objUser = objEntity.GetUserByID(id);
            if (objUser == null)
            {
                return NotFound();
            }

            objEntity.DeleteUser(id);
            return Ok(objUser);
        }
    }
}
